# Mathi JR — páginas legales para GitHub Pages

Web estática en español para el bot de Discord **Mathi JR**.

## Publicación gratis

1. Entra en GitHub y crea un repositorio **público** nuevo (sugerencia: `mathi-jr-legal`). No utilices el repositorio privado del código ni subas tokens.
2. Descarga y **extrae** el ZIP de este paquete. Sube a la raíz del repositorio los archivos `index.html`, `privacy.html`, `terms.html`, `styles.css` y `.nojekyll` (puedes subir este README también).
3. Haz commit de los cambios en la rama `main`.
4. En el repositorio, ve a **Settings → Pages → Build and deployment**, elige **Deploy from a branch**, la rama **main**, carpeta **/(root)** y guarda.
5. Usa el botón **Visit site** en Settings → Pages para conocer la URL REAL. Comprueba en modo incógnito que tanto `/privacy.html` como `/terms.html` abren públicamente (HTTP 200).
6. Pega los enlaces públicos en los campos *Privacy Policy URL* y *Terms of Service URL* de **Discord Developer Portal → General Information** o App Verification, según la ubicación en la interfaz.

## Revisión importante antes de publicar

- Confirma quién es el titular o responsable legal del bot y si se requieren datos legales adicionales según la jurisdicción.
- Comprueba que las funciones de IA enumeradas son realmente las que están activas y quién recibe los datos.
- Confirma el plazo o criterio de conservación de los datos y qué procedimiento existe para eliminarlos.
- Confirma la configuración real de cookies, autenticación del dashboard y tratamiento de archivos/voz.
- Revisa cualquier recompensa económica o contenido monetizado que pudiera requerir cláusulas adicionales.
- Pide una revisión legal apropiada: estos documentos son borradores basados en el código de Mathi JR v34.0.0, no asesoramiento jurídico ni una garantía de aprobación por Discord.

## Importante

**Los enlaces de GitHub Pages no existen hasta que hayas publicado el repositorio.** Si no puedes crear el repositorio o activar Pages, no inventes ni registres enlaces sin verificar. El bot de Railway no necesita ser modificado para publicar esta web.
